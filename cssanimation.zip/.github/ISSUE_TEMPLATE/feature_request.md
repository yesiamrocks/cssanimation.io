---
name: "\u2728 Feature Request"
about: Suggest an improvement or animation idea
title: "[FEATURE] "
labels: enhancement
---

**Describe the feature**
What should it do?

**Use case**
Why is this needed or helpful?

**Any visual reference?**
(Optional) Share links, animations, or mockups if relevant.

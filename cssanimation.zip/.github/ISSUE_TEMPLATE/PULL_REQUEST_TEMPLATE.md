## What’s Changed

Brief summary of what this PR does. If it fixes a bug or adds a new animation, mention it here.

## ✅ Checklist

- [ ] I’ve followed the contribution guidelines (`CONTRIBUTING.md`)
- [ ] My code follows the style guide
- [ ] I’ve tested this locally
- [ ] I’ve documented my changes if needed

Fixes #
